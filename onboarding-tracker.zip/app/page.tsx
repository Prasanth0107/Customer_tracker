"use client"

import { useState, useEffect } from "react"
import { LoginForm } from "@/components/login-form"
import { Dashboard } from "@/components/dashboard"
import { AdminPanel } from "@/components/admin-panel"

export interface User {
  id: string
  email: string
  name: string
  role: "super_admin" | "normal_user"
}

export interface Customer {
  id: string
  customer: string
  partner: string
  onboardingStatus: "In Progress" | "Completed" | "Blocked"
  initialRequester: string
  handoveredTo: string
  opportunity: string
  deepDiscovery: boolean
  accountsCount: number
  sourceCloud: string
  targetCloud: string
  onboardedDate?: string
  discoveryCompletedDate?: string
  costJobs: "Not Started" | "In Progress" | "Completed" | "Blocked"
  metricsJobs: "Not Started" | "In Progress" | "Completed" | "Blocked"
  mlJobs: "Not Started" | "In Progress" | "Completed" | "Blocked"
  recommsJobs: "Not Started" | "In Progress" | "Completed" | "Blocked"
  notes: string
  // New onboarded environment fields
  onboardedEnvironment?: {
    environmentName: string
    environmentType: "Production" | "Staging" | "Development" | "Testing"
    region: string
    instanceType: string
    storageSize: string
    networkConfig: string
    securityGroups: string[]
    backupEnabled: boolean
    monitoringEnabled: boolean
    autoScalingEnabled: boolean
    loadBalancerConfig: string
    databaseConfig: string
    applicationUrls: string[]
    accessCredentials: string
    deploymentDate: string
    environmentNotes: string
  }
}

// Mock data
const mockCustomers: Customer[] = [
  {
    id: "1",
    customer: "Academy of General Dentistry",
    partner: "TechPartner A",
    onboardingStatus: "In Progress",
    initialRequester: "John Smith",
    handoveredTo: "Sarah Johnson",
    opportunity: "OPP-2024-001",
    deepDiscovery: true,
    accountsCount: 5,
    sourceCloud: "AWS",
    targetCloud: "Azure",
    discoveryCompletedDate: "2024-01-15",
    costJobs: "In Progress",
    metricsJobs: "Completed",
    mlJobs: "Not Started",
    recommsJobs: "Not Started",
    notes: "Initial setup in progress",
  },
  {
    id: "2",
    customer: "Epharma",
    partner: "CloudTech Solutions",
    onboardingStatus: "Completed",
    initialRequester: "Fabio",
    handoveredTo: "Chida",
    opportunity: "OPP-2024-002",
    deepDiscovery: true,
    accountsCount: 12,
    sourceCloud: "GCP",
    targetCloud: "AWS",
    onboardedDate: "2025-07-11",
    discoveryCompletedDate: "2024-02-20",
    costJobs: "Completed",
    metricsJobs: "Completed",
    mlJobs: "Completed",
    recommsJobs: "In Progress",
    notes: "Informed Chida for final handover",
    onboardedEnvironment: {
      environmentName: "epharma-prod-env",
      environmentType: "Production",
      region: "us-east-1",
      instanceType: "t3.large",
      storageSize: "500GB SSD",
      networkConfig: "VPC with 3 subnets",
      securityGroups: ["web-sg", "db-sg", "app-sg"],
      backupEnabled: true,
      monitoringEnabled: true,
      autoScalingEnabled: true,
      loadBalancerConfig: "Application Load Balancer",
      databaseConfig: "RDS MySQL 8.0",
      applicationUrls: ["https://app.epharma.com", "https://api.epharma.com"],
      accessCredentials: "Stored in AWS Secrets Manager",
      deploymentDate: "2025-07-11",
      environmentNotes: "Production environment successfully deployed with high availability configuration",
    },
  },
  {
    id: "3",
    customer: "BCDR AerieHub",
    partner: "DataFlow Inc",
    onboardingStatus: "Blocked",
    initialRequester: "Mike Wilson",
    handoveredTo: "Alex Chen",
    opportunity: "OPP-2024-003",
    deepDiscovery: false,
    accountsCount: 3,
    sourceCloud: "Azure",
    targetCloud: "GCP",
    costJobs: "Blocked",
    metricsJobs: "Not Started",
    mlJobs: "Not Started",
    recommsJobs: "Not Started",
    notes: "Waiting for security clearance",
  },
  {
    id: "4",
    customer: "Cogna",
    partner: "InnovateTech",
    onboardingStatus: "Completed",
    initialRequester: "Lisa Brown",
    handoveredTo: "David Kim",
    opportunity: "OPP-2024-004",
    deepDiscovery: true,
    accountsCount: 8,
    sourceCloud: "AWS",
    targetCloud: "Azure",
    onboardedDate: "2024-12-15",
    discoveryCompletedDate: "2024-03-10",
    costJobs: "Completed",
    metricsJobs: "Completed",
    mlJobs: "Completed",
    recommsJobs: "Completed",
    notes: "Migration completed successfully",
    onboardedEnvironment: {
      environmentName: "cogna-azure-prod",
      environmentType: "Production",
      region: "East US 2",
      instanceType: "Standard_D4s_v3",
      storageSize: "1TB Premium SSD",
      networkConfig: "Virtual Network with 4 subnets",
      securityGroups: ["frontend-nsg", "backend-nsg", "database-nsg"],
      backupEnabled: true,
      monitoringEnabled: true,
      autoScalingEnabled: true,
      loadBalancerConfig: "Azure Load Balancer Standard",
      databaseConfig: "Azure SQL Database",
      applicationUrls: ["https://cogna-app.azurewebsites.net", "https://cogna-api.azurewebsites.net"],
      accessCredentials: "Azure Key Vault",
      deploymentDate: "2024-12-15",
      environmentNotes: "Successfully migrated from AWS to Azure with improved performance",
    },
  },
]

const mockUsers: User[] = [
  {
    id: "1",
    email: "admin@company.com",
    name: "Super Admin",
    role: "super_admin",
  },
  {
    id: "2",
    email: "user@company.com",
    name: "Normal User",
    role: "normal_user",
  },
]

export default function Home() {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [customers, setCustomers] = useState<Customer[]>(mockCustomers)
  const [users, setUsers] = useState<User[]>(mockUsers)
  const [currentView, setCurrentView] = useState<"dashboard" | "admin">("dashboard")

  useEffect(() => {
    // Check for existing session
    const savedUser = localStorage.getItem("currentUser")
    if (savedUser) {
      setCurrentUser(JSON.parse(savedUser))
    }
  }, [])

  const handleLogin = (email: string, password: string) => {
    // Simple mock authentication
    const user = users.find((u) => u.email === email)
    if (user && password === "password") {
      setCurrentUser(user)
      localStorage.setItem("currentUser", JSON.stringify(user))
      return true
    }
    return false
  }

  const handleLogout = () => {
    setCurrentUser(null)
    localStorage.removeItem("currentUser")
    setCurrentView("dashboard")
  }

  const updateCustomer = (updatedCustomer: Customer) => {
    setCustomers((prev) => prev.map((c) => (c.id === updatedCustomer.id ? updatedCustomer : c)))
  }

  const addCustomer = (newCustomer: Omit<Customer, "id">) => {
    const customer: Customer = {
      ...newCustomer,
      id: Date.now().toString(),
    }
    setCustomers((prev) => [...prev, customer])
  }

  const deleteCustomer = (customerId: string) => {
    setCustomers((prev) => prev.filter((c) => c.id !== customerId))
  }

  if (!currentUser) {
    return <LoginForm onLogin={handleLogin} />
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-gradient-to-r from-blue-500 to-blue-600 text-white p-4">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Onboarding Tracker</h1>
            <p className="text-blue-100">Rapid Assessment & Optimize</p>
          </div>
          <div className="flex items-center gap-4">
            <span className="text-sm">Welcome, {currentUser.name}</span>
            {currentUser.role === "super_admin" && (
              <div className="flex gap-2">
                <button
                  onClick={() => setCurrentView("dashboard")}
                  className={`px-3 py-1 rounded text-sm ${
                    currentView === "dashboard" ? "bg-white text-blue-600" : "bg-blue-700 hover:bg-blue-800"
                  }`}
                >
                  Dashboard
                </button>
                <button
                  onClick={() => setCurrentView("admin")}
                  className={`px-3 py-1 rounded text-sm ${
                    currentView === "admin" ? "bg-white text-blue-600" : "bg-blue-700 hover:bg-blue-800"
                  }`}
                >
                  Admin Panel
                </button>
              </div>
            )}
            <button onClick={handleLogout} className="bg-blue-700 hover:bg-blue-800 px-3 py-1 rounded text-sm">
              Logout
            </button>
          </div>
        </div>
      </header>

      {currentView === "dashboard" ? (
        <Dashboard
          customers={customers}
          currentUser={currentUser}
          onUpdateCustomer={updateCustomer}
          onAddCustomer={addCustomer}
          onDeleteCustomer={deleteCustomer}
        />
      ) : (
        <AdminPanel users={users} customers={customers} onUpdateUsers={setUsers} onUpdateCustomers={setCustomers} />
      )}
    </div>
  )
}
