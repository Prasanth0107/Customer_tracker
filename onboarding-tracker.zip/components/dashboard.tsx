"use client"

import { useState } from "react"
import type { Customer, User } from "@/app/page"
import { CustomerList } from "./customer-list"
import { CustomerDetails } from "./customer-details"
import { CustomerForm } from "./customer-form"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"

interface DashboardProps {
  customers: Customer[]
  currentUser: User
  onUpdateCustomer: (customer: Customer) => void
  onAddCustomer: (customer: Omit<Customer, "id">) => void
  onDeleteCustomer: (customerId: string) => void
}

export function Dashboard({
  customers,
  currentUser,
  onUpdateCustomer,
  onAddCustomer,
  onDeleteCustomer,
}: DashboardProps) {
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(
    customers.find((c) => c.customer === "Epharma") || customers[0] || null,
  )
  const [showAddForm, setShowAddForm] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")

  const filteredCustomers = customers.filter(
    (customer) =>
      customer.customer.toLowerCase().includes(searchTerm.toLowerCase()) ||
      customer.partner.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleAddCustomer = (customerData: Omit<Customer, "id">) => {
    onAddCustomer(customerData)
    setShowAddForm(false)
  }

  return (
    <div className="flex h-[calc(100vh-80px)]">
      {/* Left Sidebar - Customer List */}
      <div className="w-80 bg-white border-r border-gray-200 flex flex-col">
        <div className="p-4 border-b border-gray-200">
          <div className="flex justify-between items-center mb-3">
            <h2 className="font-semibold text-gray-800">Customers</h2>
            {(currentUser.role === "super_admin" || currentUser.role === "normal_user") && (
              <Button onClick={() => setShowAddForm(true)} size="sm" className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-1" />
                Add
              </Button>
            )}
          </div>
          <input
            type="text"
            placeholder="Search customers..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
        <CustomerList
          customers={filteredCustomers}
          selectedCustomer={selectedCustomer}
          onSelectCustomer={setSelectedCustomer}
        />
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        {showAddForm ? (
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold">Add New Customer</h2>
              <Button onClick={() => setShowAddForm(false)} variant="outline">
                Cancel
              </Button>
            </div>
            <CustomerForm onSubmit={handleAddCustomer} onCancel={() => setShowAddForm(false)} />
          </div>
        ) : selectedCustomer ? (
          <CustomerDetails
            customer={selectedCustomer}
            currentUser={currentUser}
            onUpdateCustomer={onUpdateCustomer}
            onDeleteCustomer={onDeleteCustomer}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-gray-500">
            <div className="text-center">
              <p className="text-lg mb-2">No customer selected</p>
              <p className="text-sm">Select a customer from the list to view details</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
