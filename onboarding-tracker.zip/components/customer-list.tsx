"use client"

import type { Customer } from "@/app/page"

interface CustomerListProps {
  customers: Customer[]
  selectedCustomer: Customer | null
  onSelectCustomer: (customer: Customer) => void
}

export function CustomerList({ customers, selectedCustomer, onSelectCustomer }: CustomerListProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed":
        return "bg-green-100 border-l-green-500"
      case "In Progress":
        return "bg-orange-100 border-l-orange-500"
      case "Blocked":
        return "bg-red-100 border-l-red-500"
      default:
        return "bg-gray-100 border-l-gray-500"
    }
  }

  return (
    <div className="flex-1 overflow-y-auto">
      {customers.map((customer) => (
        <div
          key={customer.id}
          onClick={() => onSelectCustomer(customer)}
          className={`p-3 border-b border-gray-100 cursor-pointer hover:bg-gray-50 border-l-4 ${getStatusColor(
            customer.onboardingStatus,
          )} ${selectedCustomer?.id === customer.id ? "bg-blue-50" : ""}`}
        >
          <div className="font-medium text-sm text-gray-900 mb-1">{customer.customer}</div>
          <div className="text-xs text-gray-600 mb-1">Partner: {customer.partner}</div>
          <div className="flex items-center justify-between">
            <span
              className={`text-xs px-2 py-1 rounded-full ${
                customer.onboardingStatus === "Completed"
                  ? "bg-green-100 text-green-800"
                  : customer.onboardingStatus === "In Progress"
                    ? "bg-orange-100 text-orange-800"
                    : "bg-red-100 text-red-800"
              }`}
            >
              {customer.onboardingStatus}
            </span>
            <span className="text-xs text-gray-500">{customer.accountsCount} accounts</span>
          </div>
        </div>
      ))}
      {customers.length === 0 && <div className="p-4 text-center text-gray-500 text-sm">No customers found</div>}
    </div>
  )
}
