"use client"

import { useState } from "react"
import type { Customer, User } from "@/app/page"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Server,
  Database,
  Shield,
  Globe,
  Settings,
  Calendar,
  Edit,
  Save,
  X,
  ExternalLink,
  Copy,
  CheckCircle,
  XCircle,
} from "lucide-react"

interface OnboardedEnvironmentProps {
  environment: NonNullable<Customer["onboardedEnvironment"]>
  customerName: string
  currentUser: User
  onUpdateEnvironment: (environment: NonNullable<Customer["onboardedEnvironment"]>) => void
}

export function OnboardedEnvironment({
  environment,
  customerName,
  currentUser,
  onUpdateEnvironment,
}: OnboardedEnvironmentProps) {
  const [isEditing, setIsEditing] = useState(false)
  const [editData, setEditData] = useState(environment)
  const [copiedField, setCopiedField] = useState<string | null>(null)

  const handleSave = () => {
    onUpdateEnvironment(editData)
    setIsEditing(false)
  }

  const handleCancel = () => {
    setEditData(environment)
    setIsEditing(false)
  }

  const copyToClipboard = async (text: string, fieldName: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedField(fieldName)
      setTimeout(() => setCopiedField(null), 2000)
    } catch (err) {
      console.error("Failed to copy text: ", err)
    }
  }

  const getEnvironmentTypeColor = (type: string) => {
    switch (type) {
      case "Production":
        return "bg-red-100 text-red-800 border-red-200"
      case "Staging":
        return "bg-yellow-100 text-yellow-800 border-yellow-200"
      case "Development":
        return "bg-blue-100 text-blue-800 border-blue-200"
      case "Testing":
        return "bg-purple-100 text-purple-800 border-purple-200"
      default:
        return "bg-gray-100 text-gray-800 border-gray-200"
    }
  }

  if (isEditing && currentUser.role === "super_admin") {
    return (
      <div className="space-y-6">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-semibold">Edit Environment Details</h2>
          <div className="flex gap-2">
            <Button onClick={handleSave} size="sm">
              <Save className="h-4 w-4 mr-1" />
              Save
            </Button>
            <Button onClick={handleCancel} variant="outline" size="sm">
              <X className="h-4 w-4 mr-1" />
              Cancel
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Basic Environment Info */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="environmentName">Environment Name</Label>
                <Input
                  id="environmentName"
                  value={editData.environmentName}
                  onChange={(e) => setEditData({ ...editData, environmentName: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="environmentType">Environment Type</Label>
                <Select
                  value={editData.environmentType}
                  onValueChange={(value: any) => setEditData({ ...editData, environmentType: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Production">Production</SelectItem>
                    <SelectItem value="Staging">Staging</SelectItem>
                    <SelectItem value="Development">Development</SelectItem>
                    <SelectItem value="Testing">Testing</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="region">Region</Label>
                <Input
                  id="region"
                  value={editData.region}
                  onChange={(e) => setEditData({ ...editData, region: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="deploymentDate">Deployment Date</Label>
                <Input
                  id="deploymentDate"
                  type="date"
                  value={editData.deploymentDate}
                  onChange={(e) => setEditData({ ...editData, deploymentDate: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>

          {/* Infrastructure Details */}
          <Card>
            <CardHeader>
              <CardTitle>Infrastructure</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="instanceType">Instance Type</Label>
                <Input
                  id="instanceType"
                  value={editData.instanceType}
                  onChange={(e) => setEditData({ ...editData, instanceType: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="storageSize">Storage Size</Label>
                <Input
                  id="storageSize"
                  value={editData.storageSize}
                  onChange={(e) => setEditData({ ...editData, storageSize: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="networkConfig">Network Configuration</Label>
                <Input
                  id="networkConfig"
                  value={editData.networkConfig}
                  onChange={(e) => setEditData({ ...editData, networkConfig: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="loadBalancerConfig">Load Balancer Configuration</Label>
                <Input
                  id="loadBalancerConfig"
                  value={editData.loadBalancerConfig}
                  onChange={(e) => setEditData({ ...editData, loadBalancerConfig: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>

          {/* Database & Applications */}
          <Card>
            <CardHeader>
              <CardTitle>Database & Applications</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="databaseConfig">Database Configuration</Label>
                <Input
                  id="databaseConfig"
                  value={editData.databaseConfig}
                  onChange={(e) => setEditData({ ...editData, databaseConfig: e.target.value })}
                />
              </div>
              <div>
                <Label htmlFor="applicationUrls">Application URLs (comma-separated)</Label>
                <Textarea
                  id="applicationUrls"
                  value={editData.applicationUrls.join(", ")}
                  onChange={(e) =>
                    setEditData({
                      ...editData,
                      applicationUrls: e.target.value
                        .split(",")
                        .map((url) => url.trim())
                        .filter((url) => url),
                    })
                  }
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="accessCredentials">Access Credentials</Label>
                <Input
                  id="accessCredentials"
                  value={editData.accessCredentials}
                  onChange={(e) => setEditData({ ...editData, accessCredentials: e.target.value })}
                />
              </div>
            </CardContent>
          </Card>

          {/* Security & Features */}
          <Card>
            <CardHeader>
              <CardTitle>Security & Features</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="securityGroups">Security Groups (comma-separated)</Label>
                <Input
                  id="securityGroups"
                  value={editData.securityGroups.join(", ")}
                  onChange={(e) =>
                    setEditData({
                      ...editData,
                      securityGroups: e.target.value
                        .split(",")
                        .map((sg) => sg.trim())
                        .filter((sg) => sg),
                    })
                  }
                />
              </div>
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="backupEnabled"
                    checked={editData.backupEnabled}
                    onCheckedChange={(checked) => setEditData({ ...editData, backupEnabled: !!checked })}
                  />
                  <Label htmlFor="backupEnabled">Backup Enabled</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="monitoringEnabled"
                    checked={editData.monitoringEnabled}
                    onCheckedChange={(checked) => setEditData({ ...editData, monitoringEnabled: !!checked })}
                  />
                  <Label htmlFor="monitoringEnabled">Monitoring Enabled</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="autoScalingEnabled"
                    checked={editData.autoScalingEnabled}
                    onCheckedChange={(checked) => setEditData({ ...editData, autoScalingEnabled: !!checked })}
                  />
                  <Label htmlFor="autoScalingEnabled">Auto Scaling Enabled</Label>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Notes */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle>Environment Notes</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={editData.environmentNotes}
                onChange={(e) => setEditData({ ...editData, environmentNotes: e.target.value })}
                placeholder="Enter environment-specific notes..."
                rows={4}
              />
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-xl font-semibold">Onboarded Environment Details</h2>
          <p className="text-gray-600">Environment information for {customerName}</p>
        </div>
        {currentUser.role === "super_admin" && (
          <Button onClick={() => setIsEditing(true)} variant="outline" size="sm">
            <Edit className="h-4 w-4 mr-1" />
            Edit Environment
          </Button>
        )}
      </div>

      {/* Environment Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Server className="h-4 w-4 mr-1" />
              Environment
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-semibold text-gray-900">{environment.environmentName}</p>
            <Badge className={`mt-1 ${getEnvironmentTypeColor(environment.environmentType)}`}>
              {environment.environmentType}
            </Badge>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-green-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Globe className="h-4 w-4 mr-1" />
              Region
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-semibold text-gray-900">{environment.region}</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-purple-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Calendar className="h-4 w-4 mr-1" />
              Deployed
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-semibold text-gray-900">{environment.deploymentDate}</p>
          </CardContent>
        </Card>

        <Card className="border-l-4 border-l-orange-500">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600 flex items-center">
              <Settings className="h-4 w-4 mr-1" />
              Instance Type
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-semibold text-gray-900">{environment.instanceType}</p>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Information */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Infrastructure Details */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Server className="h-5 w-5 mr-2" />
              Infrastructure Details
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-600">Storage Size</label>
                <p className="text-sm text-gray-900">{environment.storageSize}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-600">Load Balancer</label>
                <p className="text-sm text-gray-900">{environment.loadBalancerConfig}</p>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Network Configuration</label>
              <p className="text-sm text-gray-900">{environment.networkConfig}</p>
            </div>
          </CardContent>
        </Card>

        {/* Database Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Database className="h-5 w-5 mr-2" />
              Database Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-600">Database Setup</label>
              <p className="text-sm text-gray-900">{environment.databaseConfig}</p>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-600">Access Credentials</label>
              <div className="flex items-center gap-2">
                <p className="text-sm text-gray-900 flex-1">{environment.accessCredentials}</p>
                <Button
                  onClick={() => copyToClipboard(environment.accessCredentials, "credentials")}
                  variant="ghost"
                  size="sm"
                >
                  {copiedField === "credentials" ? (
                    <CheckCircle className="h-4 w-4 text-green-600" />
                  ) : (
                    <Copy className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Security Configuration */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Shield className="h-5 w-5 mr-2" />
              Security Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-600 block mb-2">Security Groups</label>
              <div className="flex flex-wrap gap-2">
                {environment.securityGroups.map((sg, index) => (
                  <Badge key={index} variant="outline">
                    {sg}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Features & Monitoring */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Settings className="h-5 w-5 mr-2" />
              Features & Monitoring
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Backup Enabled</span>
              {environment.backupEnabled ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <XCircle className="h-5 w-5 text-red-600" />
              )}
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Monitoring Enabled</span>
              {environment.monitoringEnabled ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <XCircle className="h-5 w-5 text-red-600" />
              )}
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-gray-600">Auto Scaling Enabled</span>
              {environment.autoScalingEnabled ? (
                <CheckCircle className="h-5 w-5 text-green-600" />
              ) : (
                <XCircle className="h-5 w-5 text-red-600" />
              )}
            </div>
          </CardContent>
        </Card>

        {/* Application URLs */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Globe className="h-5 w-5 mr-2" />
              Application URLs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {environment.applicationUrls.map((url, index) => (
                <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                  <span className="text-sm text-gray-900 flex-1">{url}</span>
                  <Button onClick={() => copyToClipboard(url, `url-${index}`)} variant="ghost" size="sm">
                    {copiedField === `url-${index}` ? (
                      <CheckCircle className="h-4 w-4 text-green-600" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                  <Button onClick={() => window.open(url, "_blank")} variant="ghost" size="sm">
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Environment Notes */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Environment Notes</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-900 whitespace-pre-wrap">
              {environment.environmentNotes || "No additional environment notes"}
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
